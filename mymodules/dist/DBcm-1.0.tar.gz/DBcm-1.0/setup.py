from setuptools import setup

setup (
	name='DBcm',
	version='1.0',
	description='Connecting to database',
	author='Bryan Lopez',
	author_email='bryanjlopez01@gmail.com',
	url='https://github.com/lopez2521/BecauseICare',
	py_modules=['DBcm']
	)